//
//  MainViewController.h
//  ReactNativeiOSSplit
//
//  Created by huangmingwei on 17/10/11.
//  Copyright © 2017年 Facebook. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainViewController : UIViewController

@end
