//
//  MainViewController.m
//  ReactNativeiOSSplit
//
//  Created by huangmingwei on 17/10/11.
//  Copyright © 2017年 Facebook. All rights reserved.
//

#import "MainViewController.h"
#import "ReactBridgeManager.h"
#import "ReactViewController.h"

@interface MainViewController ()

@end

@implementation MainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
  
  self.view.backgroundColor = [UIColor whiteColor];
  
  [self addButton:@"loadBaseBundle" selector:@selector(loadBaseBundle) react:CGRectMake(0, 100, 200, 50)];
  [self addButton:@"goSampleA" selector:@selector(goSampleA) react:CGRectMake(0, 200, 200, 50)];
  [self addButton:@"goSampleB" selector:@selector(loadBaseBundle) react:CGRectMake(0, 300, 200, 50)];
  
  
    // Do any additional setup after loading the view.
}

- (void)addButton:(NSString *)title selector:(SEL)selector react:(CGRect)react{
  UIButton *btn = [UIButton buttonWithType:UIButtonTypeSystem];
  [btn setBackgroundColor:[UIColor grayColor]];
  [btn addTarget:self action:selector forControlEvents:UIControlEventTouchUpInside];
  [btn setTitle:title forState:UIControlStateNormal];
  [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
  btn.frame = react;
  
  [self.view addSubview:btn];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)loadBaseBundle {
  [[ReactBridgeManager sharedInstance] setUp];
}

- (void)goSampleA {
  ReactViewController *vc = [[ReactViewController alloc] init];
  vc.moduleName = @"";
  
  
}

- (void)goSampleB {
  
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
