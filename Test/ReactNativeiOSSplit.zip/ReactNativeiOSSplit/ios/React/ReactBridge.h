//
//  ReactBridge.h
//  ReactNativeiOSSplit
//
//  Created by huangmingwei on 17/10/11.
//  Copyright © 2017年 Facebook. All rights reserved.
//

#import <React/RCTBridge.h>
#import <React/RCTBridgeDelegate.h>

typedef NS_ENUM(NSInteger, ReactBridgeStatus) {
  ReactBridgeStatusIdle          = -1,
  ReactBridgeStatusUsed     = 0,
};

@interface ReactBridge : RCTBridge

@property (nonatomic, weak) id <RCTBridgeDelegate>  bridgeDelegate;// default nil



@end
