//
//  ReactViewController.h
//  ReactNativeiOSSplit
//
//  Created by huangmingwei on 17/10/11.
//  Copyright © 2017年 Facebook. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <React/RCTBridgeDelegate.h>

@interface ReactViewController : UIViewController <RCTBridgeDelegate>

@property (nonatomic, strong) NSURL *busBundleURL;
@property (nonatomic, strong) NSString *moduleName; // default NDReactProject

@end
