//
//  ReactBridgeManager.h
//  ReactNativeiOSSplit
//
//  Created by huangmingwei on 17/10/11.
//  Copyright © 2017年 Facebook. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ReactBridge.h"

@interface ReactBridgeManager : NSObject
+ (id)sharedInstance;

- (ReactBridge *)getBridge;
- (void)setUp;

@end
