//
//  ReactBridgeManager.m
//  ReactNativeiOSSplit
//
//  Created by huangmingwei on 17/10/11.
//  Copyright © 2017年 Facebook. All rights reserved.
//

#import "ReactBridgeManager.h"
#import <React/RCTBridgeDelegate.h>


@interface ReactBridgeManager ()
@property (nonatomic, strong) NSMutableArray <ReactBridge *>*bridgePool;


@end


@implementation ReactBridgeManager
+ (id)sharedInstance {
  static ReactBridgeManager *sharedInstance = nil;
  @synchronized(self) {
    if (sharedInstance == nil)
    sharedInstance = [[ReactBridgeManager alloc] init];
  }
  
  return sharedInstance;
}

- (instancetype)init {
  self = [super init];
  if (self) {
    _bridgePool = [NSMutableArray array];
  }
  
  return self;
}

- (void)setUp {
  dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
    ReactBridge *bridge = [[ReactBridge alloc] init];
    [_bridgePool addObject:bridge];
  });
}


- (ReactBridge *)getBridge {
  ReactBridge *bridge = nil;
  
  if (_bridgePool.count > 0) {
    ReactBridge *bridge = _bridgePool[0];
    [_bridgePool removeObject:bridge];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
      ReactBridge *bridge = [[ReactBridge alloc] init];
      [_bridgePool addObject:bridge];
    });
  } else {
    bridge = [[ReactBridge alloc] init];
  }
  
  return bridge;
}



@end
