//
//  ReactBridge.m
//  ReactNativeiOSSplit
//
//  Created by huangmingwei on 17/10/11.
//  Copyright © 2017年 Facebook. All rights reserved.
//

#import "ReactBridge.h"

@interface ReactBridge () <RCTBridgeDelegate>

@end


@implementation ReactBridge

//
- (instancetype)init {
  self = [self initWithDelegate:self launchOptions:nil];
  if (self) {
    
  }
  
  return self;
}

- (NSURL *)sourceURLForBridge:(RCTBridge *)bridge {
  if (self.bridgeDelegate) {
    return [self.bridgeDelegate sourceURLForBridge:bridge];
  }

  return [[NSBundle mainBundle] URLForResource:@"index" withExtension:@"bundle" subdirectory:@"bundle/base"];
}

// 保存好basebundle， 防止多次读文件


@end
