//
//  ReactViewController.m
//  ReactNativeiOSSplit
//
//  Created by huangmingwei on 17/10/11.
//  Copyright © 2017年 Facebook. All rights reserved.
//

#import "ReactViewController.h"
#import "ReactBridge.h"
#import "ReactBridgeManager.h"
#import "ReactRootView.h"


typedef void (^RCTJavaScriptCompleteBlock)(NSError *error);

@interface ReactViewController ()
@property (nonatomic, strong)  ReactBridge *bridge;

@end

@implementation ReactViewController

- (instancetype)init {
  self = [super init];
  if (self) {
    self.bridge = [[ReactBridgeManager sharedInstance] getBridge];
    self.bridge.bridgeDelegate = self;
    self.moduleName = @"NDReactProject";
  }
  
  return self;
}


- (void)viewDidLoad {
    [super viewDidLoad];
  
  if (self.bridge) {
    // bridge excute code
      SEL method = NSSelectorFromString(@"enqueueApplicationScript:url:onComplete:");
      if ([self.bridge respondsToSelector:method]) {
          // 执行  invoke
        NSMethodSignature *methodSignature = [(id)self.bridge methodSignatureForSelector:method];
        NSInvocation *invocation = [NSInvocation invocationWithMethodSignature:methodSignature];
        invocation.target = self.bridge;
        invocation.selector = method;
        
      
        NSURL *busURL = [self sourceURLForBridge:nil];
        NSData *data = [NSData dataWithContentsOfURL:busURL];
        
        __weak typeof(self) weakSelf = self;
        RCTJavaScriptCompleteBlock block = ^(NSError *error) {
          [weakSelf excuteScriptComplete:error];
        };
        
        [invocation setArgument:&data atIndex:2];
        [invocation setArgument:&busURL atIndex:3];
        [invocation setArgument:&block atIndex:4];
        
        [invocation invoke];
      }
    }
}

- (void)excuteScriptComplete:(NSError *)error {
  if (error) {
    return;
  }
  
  ReactRootView *rootView = [[ReactRootView alloc] initWithBridge:self.bridge moduleName:self.moduleName initialProperties:nil];
  self.view = rootView;
  
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSURL *)sourceURLForBridge:(RCTBridge *)bridge {
  if (self.busBundleURL) {
    return self.busBundleURL;
  }
  
  return [[NSBundle mainBundle] URLForResource:@"index" withExtension:@"bundle" subdirectory:@"bundle/base"];
}



@end
