//
//  ReactRootView.m
//  ReactNativeiOSSplit
//
//  Created by huangmingwei on 17/10/11.
//  Copyright © 2017年 Facebook. All rights reserved.
//

#import "ReactRootView.h"

@implementation ReactRootView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
